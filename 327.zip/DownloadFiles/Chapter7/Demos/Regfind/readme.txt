RegFind OCX and EXE

- Summary
- Usage
- Contact Info and additional freeware (with source code)


Summary:

The RegFind OCX and EXE were written because I wanted a simple way to search the registry without needing to 
hit the F3 key over and over again.  I really like the Find Files interface, so I decided to use it as a basis 
for the RegFind interface.

Usage:

This code is freeware.  The source code may be used free of charge on the condition that "Lee Wallen - original author" 
is conspicuously and appropriately displayed.  There is no warranty for this free software.
Please let me know how you have used and/or modified RegFind.  


Contact Info and additional freeware (with source code):

I can be contacted at lee_wallen@yahoo.com.
Additional freeware applications with source code can be found on my webpage (in the Sample Code section) at 
http://www.nwlink.com/~leewal
