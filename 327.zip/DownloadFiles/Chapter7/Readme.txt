There is one error that I know of already in Chapter 7! Sorry!!
The first "To Try This" uses code from Listing 7-1 and 7-2.

The code in these listings is incorrect in the following ways:

1) Both the type definition and the declaration of the API call should be declared as "Private"

2) One of the lines in the Command1_Click event is incorrect. 

The correct code is contained in a project in this folder called "ToTryThisFix.vbp"

In addition, I am reproducing the correct code here:

Private Type MEMORYSTATUS
    dwLength As Long
    dwMemoryLoad As Long
    dwTotalPhys As Long
    dwAvailPhys As Long
    dwTotalPageFile As Long
    dwAvailPageFile As Long
    dwTotalVirtual As Long
    dwAvailVirtual As Long
End Type
Private Declare Sub GlobalMemoryStatus Lib "kernel32" (lpBuffer As MEMORYSTATUS)


Private Sub Command1_Click()
    Dim Memstuff As MEMORYSTATUS
    GlobalMemoryStatus Memstuff 'This line is correct, the book has an incorrect line of code here.
    Text1.Text = Str(Memstuff.dwMemoryLoad)
    Text2.Text = Str(Memstuff.dwTotalPhys)
    Text3.Text = Str(Memstuff.dwAvailPhys)
End Sub

I apologize for this mistake.
Mary
